const API_URL = 'https://localhost:3000';

const handleResponse = async (response, errorMsg) => {
    if (!response.ok) {
        throw new Error(errorMsg);
    }
    return response.json();
};

const request = (url, method = 'GET', body = null, errorMsg = 'Request failed') => {
    return fetch(`${API_URL}${url}`, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: body ? JSON.stringify(body) : null
    }).then(res => handleResponse(res, errorMsg));
};

const API = {
    init: () => console.log('API initialized with endpoint:', API_URL),

    trainers: {
        add: trainerData => request('/trainer', 'POST', trainerData, 'Failed to add trainer'),
        getAll: () => request('/trainer', 'GET', null, 'Failed to fetch trainers'),
        getById: id => request(`/trainer/${id}`, 'GET', null, 'Trainer not found'),
        getBySubject: (subject, topic = null) => {
            const url = topic
                ? `/trainer/${encodeURIComponent(subject)}/topic?topic=${encodeURIComponent(topic)}`
                : `/trainer/${encodeURIComponent(subject)}`;
            return request(url, 'GET', null, 'Failed to fetch trainers by subject');
        },
        delete: id => request(`/trainer/${id}`, 'DELETE', null, 'Failed to delete trainer'),
        addSubject: (trainerId, subjectId, topics = []) =>
            request(`/trainer/${trainerId}/subject/${subjectId}`, 'POST', { topics }, 'Failed to add subject to trainer')
    },

    subjects: {
        add: subjectData => request('/subject', 'POST', subjectData, 'Failed to add subject'),
        getAll: () => request('/subject', 'GET', null, 'Failed to fetch subjects'),
        getById: id => request(`/subject/${id}`, 'GET', null, 'Subject not found'),
        getTrainerTopics: (subjectId, trainerId) =>
            request(`/subject/${subjectId}/trainer/${trainerId}`, 'GET', null, 'Failed to fetch topics')
    }
};

document.addEventListener('DOMContentLoaded', API.init);
