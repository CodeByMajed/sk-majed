const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//store data 
let trainers = [];
let subjects = [];
let trainerCounter = 1;
let subjectCounter = 1;

//find an entity by ID
const findById = (id, dataArray) => dataArray.find(item => item.id === id);

//TRAINER

//add trainer
app.post('/trainer', (req, res) => {
    const newTrainer = { id: trainerCounter++, ...req.body, subjects: [] };
    trainers.push(newTrainer);
    res.status(201).json(newTrainer);
});

//get trainers
app.get('/trainer', (req, res) => res.json(trainers));

//get trainer by ID
app.get('/trainer/:id', (req, res) => {
    const trainer = findById(parseInt(req.params.id), trainers);
    trainer ? res.json(trainer) : res.status(404).json({ error: 'Trainer not found' });
});

//get trainers by subject
app.get('/trainer/:subject/topic', (req, res) => {
    const { subject } = req.params;
    const { topic } = req.query;
    
    const matchedTrainers = trainers.filter(trainer => 
        trainer.subjects.some(s => 
            s.name.toLowerCase() === subject.toLowerCase() && 
            (!topic || s.topics.includes(topic.toLowerCase()))
        )
    );
    res.json(matchedTrainers);
});

//delete a trainer
app.delete('/trainer/:id', (req, res) => {
    const initialLength = trainers.length;
    trainers = trainers.filter(t => t.id !== parseInt(req.params.id));
    res.status(initialLength !== trainers.length ? 200 : 404).json({ message: 'Trainer not found or deleted successfully' });
});

//add subject to a trainer
app.post('/trainer/:trainerId/subject/:subjectId', (req, res) => {
    const trainer = findById(parseInt(req.params.trainerId), trainers);
    const subject = findById(parseInt(req.params.subjectId), subjects);
    if (!trainer || !subject) return res.status(404).json({ error: 'Trainer or subject not found' });

    const existingSubject = trainer.subjects.find(s => s.id === subject.id);
    if (existingSubject) {
        existingSubject.topics = [...new Set([...existingSubject.topics, ...req.body.topics || []])];
    } else {
        trainer.subjects.push({ id: subject.id, name: subject.name, topics: req.body.topics || [] });
    }
    res.json(trainer);
});

//SUBJECT

//add subject
app.post('/subject', (req, res) => {
    const newSubject = { id: subjectCounter++, ...req.body };
    subjects.push(newSubject);
    res.status(201).json(newSubject);
});

//get all subjects
app.get('/subject', (req, res) => res.json(subjects));

// Get subject by ID with associated trainers
app.get('/subject/:id', (req, res) => {
    const subject = findById(parseInt(req.params.id), subjects);
    if (subject) {
        const teachingTrainers = trainers.filter(trainer => 
            trainer.subjects.some(s => s.id === subject.id)
        );
        res.json({ ...subject, teachingTrainers });
    } else {
        res.status(404).json({ error: 'Subject not found' });
    }
});

//get a subject
app.get('/subject/:subjectId/trainer/:trainerId', (req, res) => {
    const trainer = findById(parseInt(req.params.trainerId), trainers);
    if (!trainer) return res.status(404).json({ error: 'Trainer not found' });

    const subject = trainer.subjects.find(s => s.id === parseInt(req.params.subjectId));
    subject ? res.json(subject.topics) : res.status(404).json({ error: 'Subject not found for this trainer' });
});

//startserver
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
