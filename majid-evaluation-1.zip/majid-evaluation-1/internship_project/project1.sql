-- Create database
CREATE DATABASE IF NOT EXISTS training_institute;
USE training_institute;

-- Table for Trainers
CREATE TABLE trainers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    specialization VARCHAR(100)
);

-- Table for Subjects
CREATE TABLE subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT
);

-- Optional: Mapping table for trainer-subject relationships (many-to-many)
CREATE TABLE trainer_subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    trainer_id INT,
    subject_id INT,
    FOREIGN KEY (trainer_id) REFERENCES trainers(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
);